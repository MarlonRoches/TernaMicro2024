# Arreglos 🪜

Coleccion de datos, con orden, del mismo datos en orden consecutivo.