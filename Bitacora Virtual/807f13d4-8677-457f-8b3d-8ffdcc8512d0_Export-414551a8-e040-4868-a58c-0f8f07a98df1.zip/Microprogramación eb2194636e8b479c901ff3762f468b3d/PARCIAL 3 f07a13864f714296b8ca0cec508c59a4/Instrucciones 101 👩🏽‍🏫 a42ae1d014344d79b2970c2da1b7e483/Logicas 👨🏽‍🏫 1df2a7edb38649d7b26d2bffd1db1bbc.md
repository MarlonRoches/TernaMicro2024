# Logicas 👨🏽‍🏫

## AND destino, fuente

Operación lógica AND a nivel de bits.

```nasm
flag1 && flag2
```

## OR destino, fuente

Operación lógica OR a nivel de bits.

```nasm
flag1 ||flag2
```

## XOR destino, fuente

Operación lógica XOR a nivel de bits.

## NOT Destino

Operación lógica NOT. Complementa
los bits del operando

```nasm
!flag1
```