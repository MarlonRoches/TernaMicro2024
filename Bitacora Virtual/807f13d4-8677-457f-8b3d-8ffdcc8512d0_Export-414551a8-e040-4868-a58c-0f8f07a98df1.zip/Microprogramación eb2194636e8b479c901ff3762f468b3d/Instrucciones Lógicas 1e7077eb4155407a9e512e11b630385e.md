# Instrucciones Lógicas

# TEST fuente1, fuente2

- Realiza un AND sin almacenar resultado.
- Activa o desactiva bandera ⛳ 0

```jsx
TEST fuente1, fuente2
```

# CMP fuente1, fuente2

- Realiza una entre los operadores, sin almacenar resultado.
- Actualiza Banderas ⛳

```jsx
CMP fuente1, fuente2
```