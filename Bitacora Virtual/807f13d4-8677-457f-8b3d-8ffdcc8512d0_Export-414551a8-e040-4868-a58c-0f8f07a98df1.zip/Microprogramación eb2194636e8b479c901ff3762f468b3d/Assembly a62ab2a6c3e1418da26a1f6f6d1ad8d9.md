# Assembly

# Turbo

- 8 y 16 bits
- Windows
- **ENLAZADOR** TurboLinker
    - Proceso similar al del compilación, genera el programa objeto.
    - Toma el programa traducido a maquina y recolecta los recursos que necesita para ejecutarse.
- Inter 8086 - 80286

## SEGMENTOS MINIMOS

Codigo y pila

# Estructura

## Palabras reservadas:

Nemotecnicos, cadenas reservadas a una cadena simple. (MOV LEA ETC)

## Directivas

Instrucciones previas al procesador antes de ejecutar el programa.

- .model, .stock

## Operadores

- ADD, SUB, etc

## Símbolos Predefinidos

Palabras reservadas con funciones especificas a ejecutar.

## Modelo

De que tamaño será cada segmento de codigo y datos. Define la estructura de el lenguaje.

# 

[Tipos de Modelos](Assembly%20a62ab2a6c3e1418da26a1f6f6d1ad8d9/Tipos%20de%20Modelos%20a51b928e35d9442d9c8ee872fcf6d271.md)

[Directivas](Assembly%20a62ab2a6c3e1418da26a1f6f6d1ad8d9/Directivas%20793aa4517de042f6b686ebf24dc921bc.md)

[Identificadores](Assembly%20a62ab2a6c3e1418da26a1f6f6d1ad8d9/Identificadores%2008cc01b19da846a8b70ef7453b0a2965.md)

[Instrucciones](Assembly%20a62ab2a6c3e1418da26a1f6f6d1ad8d9/Instrucciones%20b306055316e64212aea22fb086bea427.md)

[101](Assembly%20a62ab2a6c3e1418da26a1f6f6d1ad8d9/101%20660803c78691482ca58cc497878df5f9.md)