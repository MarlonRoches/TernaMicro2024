# SALTOS

## JMP dir

```jsx
JMP dir //salta a la etiqueta que querramos
```

## JE dir (if)

Salta si la bandera 0 está activada.

- Resultado de CMP

```jsx
JE dir
// if( (Z) banderaCero == 1 )
 
//comparar registros iguales = 0
```

## JZ dir

Lo mismo que JE pero comparando numeros.

## JNE / JNZ dir (else)

## JS dir

Cuando la bandera de negativo esta en 1.

## JL dir

Operacion numerica.

Salto