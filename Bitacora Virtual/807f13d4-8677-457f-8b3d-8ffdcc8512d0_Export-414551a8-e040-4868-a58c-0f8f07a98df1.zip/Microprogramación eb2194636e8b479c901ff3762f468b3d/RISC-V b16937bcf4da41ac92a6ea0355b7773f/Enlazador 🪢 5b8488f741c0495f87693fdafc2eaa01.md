# Enlazador 🪢

Obtiene los recursos del pc para su ejecucion y crea el ejecutable.

- Puede incluir instrucciones de alto nivel, como llamadas a librerias incluidas.