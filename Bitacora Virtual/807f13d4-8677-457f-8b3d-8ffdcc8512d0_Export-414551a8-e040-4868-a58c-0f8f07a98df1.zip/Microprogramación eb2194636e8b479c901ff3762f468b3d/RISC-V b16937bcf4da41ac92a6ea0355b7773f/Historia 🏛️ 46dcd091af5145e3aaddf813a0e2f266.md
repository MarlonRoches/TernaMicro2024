# Historia 🏛️

## Que resuelve?

ISA: Arquitectura de set de instrucciones

Las **ISA** eran complejas y con derechos de propiedad. ©️

Partiendo del el Intel 8086 (80 instrucciones y 86 de SO), el set de x86, parte con 80 instrucciones de 1978.

## 2014

Habia 1338 instrucciones en su version de x86 de 32 bits.

# Origen 🐣

- (RISC) Reduced Instruction Set Computer inicio como proyecto temporal en Berkley.
- Nace de para ser una herramienta libre.
- Tiene als caracteristicas mas importantes.
- Es modular, puede crecer, adaptar y escalar.

### Core Risc5 (RV32i)

Version de nucleo fundamental para dar tratamiendo a bajo nivel.

- Permite extensiones para crecer.

Multiplicaciones: RV32FM y RV32F flotante.

### Set

Tratamiento para un programa de bajo nivel.