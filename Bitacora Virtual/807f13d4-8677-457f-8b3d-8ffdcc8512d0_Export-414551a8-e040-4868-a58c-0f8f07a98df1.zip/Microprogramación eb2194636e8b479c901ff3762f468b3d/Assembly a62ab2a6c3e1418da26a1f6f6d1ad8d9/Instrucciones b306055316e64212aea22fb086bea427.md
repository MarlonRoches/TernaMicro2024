# Instrucciones

Conjunto de enemónicos e identificadores validos, que en el cnjunto ejecutan una accion del programa.