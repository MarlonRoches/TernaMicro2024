# Identificadores

Nombres que se le asignan a elementos específicos , asignados por el programador.

REGEX: L (L|D|C)*

NUMEROS: D+(b|d|h)?