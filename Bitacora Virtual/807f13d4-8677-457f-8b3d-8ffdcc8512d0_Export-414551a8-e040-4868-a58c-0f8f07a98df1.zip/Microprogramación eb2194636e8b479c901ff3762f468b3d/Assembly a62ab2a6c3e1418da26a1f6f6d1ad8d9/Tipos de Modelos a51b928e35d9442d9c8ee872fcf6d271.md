# Tipos de Modelos

# Modelos de 16 bits

### Segmentos

🟢 Datos

🔵Codigo

🟠Pila

### Tiny

### Small

### Compact:

Datos crean nuevos segmentos al llenar, código en segmento unico.

Reserva dinamica de espacios.

🟠

🟢🟢

🔵

### Medium

Maneja pocos datos pero tiene muchas instrucciones.

Creacion de segmentos 64kb c/u.

🟠

🟢

🔵🔵

### Large:

Datos y codigo se generan segmentos de datos y de codigo de forma dinamica.

Se reservan espacios hasta que sea suficiente.

🟠

🟢🟢

🔵🔵